# HPRGhostReplay v0.1 源码审阅包

作者：LoughShinny302
对应版本：0.1.0-beta.11（v0.1）。这是供指定开发者审阅和协作的源码快照。

## 构建

需要 Windows x64、系统 .NET Framework 4.x C# 编译器，以及 Zig 0.13.0 Windows x64。编译器不随源码包提供。
Zig 官方下载：https://ziglang.org/download/0.13.0/zig-windows-x86_64-0.13.0.zip
下载包 SHA256：d859994725ef9402381e557c60bb57497215682e355204d754ee3df75ee3c158

在本目录打开 PowerShell，例如：

    .\Build.ps1 -ZigPath 'C:\Tools\zig\zig.exe'

先编译 native/src 和包内 MinHook，再将生成的 HPRGhostNative.asi、名称表及官方 x64 加载器内嵌至 HPRGhostReplay.exe。
也可将 Zig 放入 tools/zig/ 或 PATH，随后直接运行 Build.ps1。

开发构建与离线检查：

    .\Build.ps1 -Configuration Development -ZigPath 'C:\Tools\zig\zig.exe'
    .\HPRGhostReplay-dev.exe --self-test

离线检查不需要游戏。结果写入 research/selftest-results.txt。两项依赖实机内存样本的可选检查会跳过，因为本包不包含这些样本。测试临时目录受 .NET Framework 路径长度限制，建议解压至较短路径。
原生协议与插值检查：

    .\native\build\NativeSmoke.exe --payload .\research\native-payload.bin .\research\native-expected.bin

普通构建和离线自检不会安装游戏插件。直接打开编译后的正常主界面会自动查找游戏并安装必备组件，操作方式见 release/使用说明.txt。

## 代码入口

- Program.cs、ControlWindow.cs、UiControls.cs、UiText.cs：入口、界面与开关状态。
- GameReader.cs、GameLayout.cs、FrameSampling.cs、Lifecycle.cs：只读采样、布局匹配、赛事识别及整场录制。
- Core.cs、ReplayLibrary.cs：姿态插值、录像格式与录像库管理。
- ModelResources.cs：从使用者本机游戏目录读取实际车辆模型。
- NativePlayback.cs、native/src/Channel.hpp：主工具与原生组件的数据传递。
- native/src/NativeGhost.cpp：D3D11 Present/ResizeBuffers 挂接与半透明绘制。
- AsiLoader.cs、SteamGameDiscovery.cs、ComponentDialog.cs：启动安装、目录识别与卸载。
- 其余 *Tests.cs：离线检查。Development 构建还保留诊断工具和历史绘图器；它们不进入 Release。

## 整理范围

当前项目 C# 与原生功能源码保持不变。构建脚本改为包内相对路径，去掉对作者研究目录的依赖；图标改为本包原创的简单占位图标。
包含 MinHook 1.3.4 源码及其许可；官方 Ultimate ASI Loader 9.7.4 x64 以未修改 DLL 附带，源码地址：https://github.com/ThirteenAG/Ultimate-ASI-Loader/tree/v9.7.4

不含游戏EXE、车辆模型、解包资源、第三方游戏修改插件、个人录像、游戏路径配置、日志、内存转储、研究样本或历史构建。
包中的 events.tsv、vehicles.tsv 是程序使用的赛事和车型名称表，不是车辆模型文件。
第三方许可见 release/第三方许可.txt。源码使用范围见 SOURCE-NOTICE.txt。
