param([string]$OutputName = '', [ValidateSet('Release','Development')][string]$Configuration = 'Release', [string]$ZigPath = '')
$ErrorActionPreference = 'Stop'
if (!$OutputName) { if ($Configuration -eq 'Release') { $OutputName='HPRGhostReplay.exe' } else { $OutputName='HPRGhostReplay-dev.exe' } }
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'Missing .NET Framework 4.x x64 C# compiler' }
Push-Location $PSScriptRoot
try {
 $nativeSources=Get-ChildItem -LiteralPath 'native\src' -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
 if(!(Test-Path -LiteralPath 'native\bin\HPRGhostNative.asi') -or $nativeSources.LastWriteTimeUtc -gt (Get-Item -LiteralPath 'native\bin\HPRGhostNative.asi').LastWriteTimeUtc){& (Join-Path $PSScriptRoot 'native\Build.ps1') -ZigPath $ZigPath}
 $wpfRoot=Join-Path (Split-Path $compiler -Parent) 'WPF'
 $buildArgs = @('/nologo','/target:winexe','/platform:x64','/optimize+','/codepage:65001','/win32icon:assets\HPRGhostReplay.ico','/resource:assets\HPRGhostReplay.ico,HprGhost.AppIcon.ico','/resource:events.tsv,HprGhost.events.tsv','/resource:vehicles.tsv,HprGhost.vehicles.tsv',('/out:"'+$OutputName+'"'),'/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll',('/reference:'+ (Join-Path $wpfRoot 'PresentationCore.dll')),('/reference:'+ (Join-Path $wpfRoot 'PresentationFramework.dll')),('/reference:'+ (Join-Path $wpfRoot 'WindowsBase.dll')),'/reference:System.Xaml.dll','Core.cs','GameLayout.cs','GameReader.cs','Lifecycle.cs','Program.cs','ModelResources.cs','ModelOverlay.cs','Timing.cs','FrameSampling.cs','ReplayLibrary.cs','UiControls.cs','UiText.cs','ControlWindow.cs','AppPaths.cs','AppLog.cs','ErrorLog.cs')
 $buildArgs=$buildArgs | Where-Object {$_ -ne 'ModelOverlay.cs'}
 $buildArgs+=@('/resource:native\bin\HPRGhostNative.asi,HprGhost.Native.asi','NativePlayback.cs','AsiLoader.cs','SteamGameDiscovery.cs','ComponentDialog.cs','/resource:native\bin\UltimateASILoader-x64.dll,HprGhost.AsiLoader.dll')
 if ($Configuration -eq 'Development') { $buildArgs += @('/define:DEVELOPMENT','DevelopmentTools.cs','SamplingDiagnostics.cs','TimingDiagnostics.cs','DevelopmentLog.cs','SelfTests.cs','ModelChecks.cs','ModelOverlay.cs','UiTests.cs','BilingualUiTests.cs','VehicleNameTests.cs','LogTests.cs','ReleaseLogTests.cs','NativeTests.cs','LoaderTests.cs','StartupInstallTests.cs','NativeUiCheck.cs') }
 $build = Start-Process -FilePath $compiler -ArgumentList $buildArgs -NoNewWindow -Wait -PassThru
 if ($build.ExitCode -ne 0) { throw ('Build failed: '+$build.ExitCode) }
 Write-Output ('Built '+$Configuration+': '+$OutputName)
} finally { Pop-Location }





